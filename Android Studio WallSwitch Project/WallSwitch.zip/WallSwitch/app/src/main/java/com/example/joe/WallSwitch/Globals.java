package com.example.joe.WallSwitch;

/**
 * Created by Joe on 4/21/2017.
 */

public class Globals {

    public static String lightStatus = "0";
    public static String accessToken = "Your Particle Access Token Goes Here";


    public static String coreID = "Your Photon ID Goes Here";
    public static int getError = 0;
    public static int postError = 0;

}
