package com.example.joe.WallSwitch;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {

    // Declare UI objects
    TextView lightStateText;
    TextView connErrorText;
    TextView status;
    ProgressBar spinner1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.i("Info", "Entered");

        status = (TextView) findViewById(R.id.status);
        status.setText("Starting App ...");

        // Prepare and execute particle GET, set busy indicator, set fetch data UI messages
        Globals.getError = 0;
        particleGET task1GET = new particleGET();
        task1GET.execute("https://api.particle.io/v1/devices/" + Globals.coreID +
                "/lightState/?access_token=" + Globals.accessToken);
        Log.i("Info", "Past GET");

        spinner1 = (ProgressBar)findViewById(R.id.spinner1);
        spinner1.setVisibility(View.VISIBLE);

        lightStateText = (TextView) findViewById(R.id.lightStateText);
        lightStateText.setText("Fetching Light Status ...");
    }

    // onClick handler for "Turn Light On" button
    public void turnLightOnFunction(View view) {
        Globals.lightStatus = "1";
        particleParamsPOST();
    }

    // onClick handler for "Turn Light Off" button
    public void turnLightOffFunction(View view) {
        Globals.lightStatus = "0";
        particleParamsPOST();
    }

    // onClick handler for "Refresh Status" button
    public void refreshFunction(View view) {

        spinner1 = (ProgressBar)findViewById(R.id.spinner1);
        spinner1.setVisibility(View.VISIBLE);
        Log.i("Info", "Spinner On");
        lightStateText = (TextView) findViewById(R.id.lightStateText);
        lightStateText.setText("Confirming Light Switch Status ...");
        Log.i("Info", "Light Text Should Have Been Set");
        particleGET task1GET = new particleGET();
        task1GET.execute("https://api.particle.io/v1/devices/" + Globals.coreID +
                "/lightState/?access_token=" + Globals.accessToken);
    }


// Assemble parameters for particle POST, call 3 particle POSTS, set busy indicator
    public void particleParamsPOST() {
        Globals.postError = 0;

        // Erase connection error text (if there IS ANY)
        connErrorText = (TextView) findViewById(R.id.connErrorText);
        connErrorText.setText("");

        // Set text for POST data send
        lightStateText = (TextView) findViewById(R.id.lightStateText);
        lightStateText.setText("Sending Light Command ...");
        spinner1 = (ProgressBar)findViewById(R.id.spinner1);
        spinner1.setVisibility(View.VISIBLE);

        // Call async tasks to do Particle POSTs
        particlePOST ranchPOST = new particlePOST();
        ranchPOST.execute(Globals.lightStatus);
    }

    // Error handler in case Particle POST fails
    public void exceptionPOSTNotifier() {
        Log.i("Info", "Got To exceptionPOSTNotifier");
        Globals.postError = 1;
        connErrorText = (TextView) findViewById(R.id.connErrorText);
        connErrorText.setText(getString(R.string.connError));
        spinner1 = (ProgressBar)findViewById(R.id.spinner1);
        spinner1.setVisibility(View.GONE);
    }

    // Error handler in case Particle GET fails
    public void exceptionGETNotifier() {
        Log.i("Info", "Got To exceptionGETNotifier");
        Globals.getError = 1;
        lightStateText = (TextView) findViewById(R.id.lightStateText);
        connErrorText = (TextView) findViewById(R.id.connErrorText);
        connErrorText.setText(getString(R.string.connError));
        spinner1 = (ProgressBar)findViewById(R.id.spinner1);
        spinner1.setVisibility(View.GONE);
    }


    // Async Particle POST, receives params and issues POST to Particle cloud
    public class particlePOST extends AsyncTask<String, Void, String> {

        @Override
        protected void onCancelled() {
            exceptionPOSTNotifier();
        }

        @Override
        public String doInBackground(String... myparam) {

            String result = "";
            String myParam = new String(myparam[0]);
            Log.i("Info myPARAM", myParam);
            Log.i("Info", Integer.toString(Globals.getError));

            URL url;
            try {
                url = new URL("https://api.particle.io/v1/devices/" + Globals.coreID + "/switchLight/");
                String param = "access_token=" + Globals.accessToken + "&params=" + myParam;
                Log.i("Info", param);
                HttpsURLConnection urlConnection = (HttpsURLConnection) url.openConnection();

                urlConnection.setReadTimeout(7000);
                urlConnection.setConnectTimeout(7000);
                urlConnection.setDoOutput(true);
                urlConnection.setDoInput(true);
                urlConnection.setInstanceFollowRedirects(false);
                urlConnection.setRequestMethod("POST");
                urlConnection.setFixedLengthStreamingMode(param.getBytes().length);
                urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                // Send
                PrintWriter out = new PrintWriter(urlConnection.getOutputStream());
                out.print(param);
                out.close();
                urlConnection.connect();

                BufferedReader in = null;

                if (urlConnection.getResponseCode() != 200) {
                    // I think you want to cancel here
                    in = new BufferedReader(new InputStreamReader(urlConnection.getErrorStream()));
                    Log.d("Info", "!=200: " + in);
                }
                else {
                    Log.i("Info", " Past 200");
                    InputStream inX = urlConnection.getInputStream();
                    InputStreamReader reader = new InputStreamReader(inX);
                    int data = reader.read();
                    while (data != -1) {
                        char current = (char) data;
                        result += current;
                        data = reader.read();
                    }
                    Log.i("Response", result);
                    JSONObject jsonObject = new JSONObject(result);
                    String createReturnValue = jsonObject.getString("return_value");

                    doParticleGet();
                }

            } catch (Exception e) {
                Log.d("Info", "POST Exception");
                e.printStackTrace();
                cancel(true);
                return null;
            }
            return null;
        }
    }


    public void doParticleGet() {
        particleGET refresh = new particleGET();
        refresh.execute("https://api.particle.io/v1/devices/" + Globals.coreID +
                "/lightState/?access_token=" + Globals.accessToken);
    }


    // Async Particle GET, issues GET to received url
    public class particleGET extends AsyncTask<String, Void, String> {

        @Override
        protected void onCancelled() {
            exceptionGETNotifier();
        }

        @Override
        public String doInBackground(String... urls) {
            String resultRTN = "";
            URL url;

            try {
                url = new URL(urls[0]);

                Log.i("Info", "Received URL:  " + url);
                HttpsURLConnection urlConnection = (HttpsURLConnection) url.openConnection();
                urlConnection.setReadTimeout(7000);
                urlConnection.setConnectTimeout(7000);

                InputStream in = urlConnection.getInputStream();
                InputStreamReader reader = new InputStreamReader(in);
                if (urlConnection.getResponseCode() != 200) {
                    Log.i("INFO", "Response Code Error");
                }
                else {
                    int data = reader.read();
                    while (data != -1) {
                        char current = (char) data;
                        resultRTN += current;
                        data = reader.read();
                    }
                    return resultRTN;

                }

            } catch (Exception e) {
                e.printStackTrace();
                Log.i("Info", "GET Exception before JSON");
                cancel(true);
            }
            finally {
            }
            return null;
        }

        // Decode response from GET
        @Override
        protected void onPostExecute(String resultRTN) {
            super.onPostExecute(resultRTN);

            // Extract JSON data
            try {
                JSONObject jsonObject = new JSONObject(resultRTN);
//                Log.i("resultRTN = ", jsonObject.toString());

                String particleVariable = jsonObject.getString("result");
                Log.i("particleVariable = ", particleVariable);

                int tempLightSwitchState = Integer.parseInt(particleVariable);
//                Log.i("Temp Program Control = ", Integer.toString(tempPgmControl));


                if (tempLightSwitchState == 1) {
                    status = (TextView) findViewById(R.id.status);
                    status.setText("Light Is On");

                } else if (tempLightSwitchState == 0) {
                    status = (TextView) findViewById(R.id.status);
                    status.setText("Light Is Off");

                } else if (Globals.getError == 1) {
                        Globals.getError = 0;
                        Globals.postError = 0;
                }
                spinner1 = (ProgressBar)findViewById(R.id.spinner1);
                spinner1.setVisibility(View.GONE);
                lightStateText = (TextView) findViewById(R.id.lightStateText);
                lightStateText.setText("");
            }

            catch(JSONException e){
                e.printStackTrace();
                Log.i("Info", "GET Exception after JSON");
                cancel(true);
            }

            finally {
            }
        }

    }
}