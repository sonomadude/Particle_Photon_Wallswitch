//
//  ViewController.swift
//  test
//
//  Created by Joe on 4/25/17.
//  Copyright © 2017 Joe. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController {


    
    @IBAction func refresh(_ sender: Any) {
        viewDidLoad()
    }


    @IBAction func postSomeData(_ sender: UIButton) {
        spinner.startAnimating()
        spinner.isHidden = false
        self.statusText.text = ""
        self.error.text = ""

        print(sender)
        var actionToTake: Int = 1
        if sender.tag == 3 {
            actionToTake = 1
        } else if sender.tag == 1 {
            actionToTake = 0
        }
        let urlAUX = URL(string: "https://api.particle.io/v1/devices/Your Photon ID Here/switchLight/")!
        let session = URLSession.shared
        let request = NSMutableURLRequest(url: urlAUX)
        
        request.httpMethod = "POST"
        request.cachePolicy = URLRequest.CachePolicy.reloadIgnoringCacheData
        
        let paramString = "access_token=Your Access Token Here&params=" + String(actionToTake)
        request.httpBody = paramString.data(using: String.Encoding.utf8)
        
        let taskPOST = session.dataTask(with: request as URLRequest) { (data, response, error) in
            if error != nil  {
                print("There was an error")
                self.error.text = "Communication Error, Try Again"
            } else {
                if let urlPOSTContent = data {
                    do {
                        let jsonResult = try JSONSerialization.jsonObject(with: urlPOSTContent, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                        var returnedValue: Int?
                        returnedValue = jsonResult["return_value"]! as? Int
                        print(returnedValue!)
                        self.viewDidLoad()
                    } catch {
                        print("There was a POST JSON error")
                        self.error.text = "Communication Error, Try Again"
                    }
                }
            }
        }
        taskPOST.resume()
    }

    
    @IBOutlet weak var statusText: UILabel!
    @IBOutlet weak var spinner: UIActivityIndicatorView!
    @IBOutlet weak var error: UILabel!
 
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.statusText.text = ""
        self.error.text = ""
        spinner.startAnimating()
        spinner.isHidden = false

// Display returned message
         func processData(tempGateState: Int) {
         if (tempGateState == 0) {
                self.statusText.text = "Light Is Off"
         } else if (tempGateState == 1) {
            self.statusText.text = "Light Is On"
         } else  {
            self.error.text = "Communication Error, Try Again"
         }
            spinner.isHidden = true
            spinner.stopAnimating()
         }

        enum connectionError: Error {
            case timeout(String)
            case other(String)
        }
        
// Particle GET routine
        func particleGET () {
        let url = URL(string: "https://api.particle.io/v1/devices/Your Photon ID Here/lightState/?access_token=Your Access Token Here")!
        let taskGET = URLSession.shared.dataTask(with: url) {(data, response, error) in
        if error != nil {
            print("GET Error not nil")
            print(error!)
            self.spinner.stopAnimating()
            self.error.text = "Connection Error, Try Again"
        } else {
            if let urlContent = data {
                do {
                    let jsonResult = try JSONSerialization.jsonObject(with: urlContent, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                        print(jsonResult)
                        print(jsonResult["result"])
                    guard let returnedValue = jsonResult["result"]! as? Int else {
                        throw connectionError.timeout("Time Out")
                    }
                        processData(tempGateState: returnedValue)
                    } catch {
                        print("GET JSON Processing Failed")
                        self.spinner.stopAnimating()
                        self.error.text = "Connection Error, Try Again"
                   }
                }
            }
        }
        taskGET.resume()
    }
        particleGET()
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
